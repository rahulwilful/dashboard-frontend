import baccarat1 from 'src/assets/baccaratTables/1.png'

export const BaccaratTables = [
    {table:baccarat1}
    ]